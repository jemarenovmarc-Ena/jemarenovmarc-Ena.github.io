JEMA RENOV — PACK DU SITE VITRINE

FICHIERS
- index.html : page d’accueil complète
- styles.css : style premium bleu/blanc, responsive
- script.js : navigation mobile et formulaire e-mail
- mentions-legales.html : modèle à compléter
- assets/logo-jema-renov.jpg : logo fourni recadré
- robots.txt et sitemap.xml : fichiers de base SEO

MISE À JOUR SUR GITHUB PAGES
1. Décompressez le ZIP.
2. Ouvrez le dépôt jemarenovmarc-Ena.github.io sur GitHub.
3. Cliquez sur Add file > Upload files.
4. Téléversez index.html, styles.css, script.js, mentions-legales.html, robots.txt, sitemap.xml et le dossier assets avec le logo.
5. Remplacez l’ancien index.html quand GitHub le propose. Conservez exactement ce nom.
6. Cliquez sur Commit changes et attendez quelques minutes.
7. Visitez https://jemarenovmarc-ena.github.io/

À PERSONNALISER AVANT DE PROMOUVOIR
- Remplacez les blocs PHOTO AVANT / PHOTO APRÈS et le visuel principal par vos vraies photos de chantier.
- Complétez les descriptions de chaque projet avec commune et travaux réellement réalisés.
- Remplacez le lien de recherche Google par le lien direct de votre fiche d’établissement.
- Complétez mentions-legales.html avec les informations exactes de l’entreprise et vérifiez les mentions requises.
- Vérifiez chaque prestation affichée, vos coordonnées et votre zone réelle d’intervention.
- Le formulaire prépare un e-mail prérempli. Il ne stocke pas les demandes et le visiteur doit envoyer l’e-mail lui-même.
- Aucun faux avis, qualification, garantie ou chantier n’est ajouté.

SEO
Le site comprend titres et méta-description, canonical, Open Graph, données structurées Plumber, sitemap, robots.txt et navigation mobile. Après publication, ajoutez le site à Google Search Console et demandez l’indexation. Les données structurées doivent rester exactes.
Le site utilise un sous-domaine GitHub Pages gratuit. Un domaine personnalisé .fr ou .com n’est pas inclus.
